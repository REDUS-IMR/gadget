# GadgetR

__WARNING: Currently, most of the implemented R functions are rudimentary. Beware of bugs and errors!__

## Install

Just install the package using the devtools's `install_local()` or `install_github()`. 

## Examples

You can find several R-script files that use this library in the `examples/` directory.

