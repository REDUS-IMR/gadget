## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

# source: https://stackoverflow.com/questions/23114654
hook_output <- knitr::knit_hooks$get("output")
knitr::knit_hooks$set(output = function(x, options) {
   lines <- options$output.lines
   if (is.null(lines)) {
     return(hook_output(x, options))  # pass to default hook
   }
   x <- unlist(strsplit(x, "\n"))
   more <- "..."
   if (length(lines)==1) {        # first n lines
     if (length(x) > lines) {
       # truncate the output, but add ....
       x <- c(head(x, lines), more)
     }
   } else {
     x <- c(more, x[lines], more)
   }
   # paste these lines together
   x <- paste(c(x, ""), collapse = "\n")
   hook_output(x, options)
})

## ----setup--------------------------------------------------------------------
library(gadgetr)

## -----------------------------------------------------------------------------
# Get the path of the example haddock data
exPath <- gadgetr::loadExample()
print(exPath)

# Init the haddock model
gadgetr::initGadget(exPath, "refinputfile")

# Print info
gadgetr::getEcosystemInfo()

# Init seed
set.seed(1098765)

## -----------------------------------------------------------------------------
# Calculate SSB
calcSSB <- function(stk) {
    # Get SSB
    subs <- stk[stk[, "age"] >= 3 & stk[, "step"] == 4, ]
    ssb <- sum(subs[, "number"] * subs[, "meanWeights"])
    return(ssb)
}

## -----------------------------------------------------------------------------
# Calculate Recruitment
calcRecruitment <- function(stk) {
    # Get Recruitment (based on fbar and only from the last step)
    subs <- stk[stk[, "age"] == 1 & stk[, "step"] == 2, ]
    return(sum(subs[, "number"]))
}

## -----------------------------------------------------------------------------
# Supposed the haddock recruitment forecast for a given year is a matter of
# picking a random number...
fcRecruitment <- function() {
    return(sample(1:25, 1) * 1000)
}

## -----------------------------------------------------------------------------
# ... and calculating TAC is a matter of taking 35% of the stock's last year
# SSB value
calcTAC <- function(ssb) {
    return(.4 * ssb)
}

## -----------------------------------------------------------------------------
# Placeholders for values
stats <- list()
ssb <- list()
fcrec <- list()
rec <- list()

# Loop for the hindcast period
forecastYear <- 2000
status <- gadgetr::getEcosystemInfo()
while ( status[["time"]]["currentYear"] < forecastYear ) {
  # Append stats
  curYr <- as.character(status[["time"]]["currentYear"])
  stats[[curYr]] <- gadgetr::runYear()
  ssb[[curYr]] <- calcSSB(stats[[curYr]]$stock$had$stk)
  # Get the latest runtime information
  status <- gadgetr::getEcosystemInfo()
}

## ----output.lines=25----------------------------------------------------------
# MSE loop
while ( status[["time"]]["finished"] != 1 ) {
  # Time calculation
  curYr <- status[["time"]]["currentYear"]
  lastYr <- curYr - 1
  
  # Calculate Recruitment for this year
  recNumber <- fcRecruitment()
  fcrec[[as.character(curYr)]] <- recNumber
  print(paste("Recruitment in", curYr, "is", recNumber))

  # Apply recruitment number for this year haddock stock
  # note that this is similar to the format found in "had.rec" file
  updateRenewal("had", curYr, step = 1, area = 1, age = 1,
      number = recNumber, mean = 16.41, sdev = 2.25 , alpha = 8.85e-6,
      beta = 3.0257)

  # Calculate last year SSB
  ssb[[as.character(lastYr)]] <- 
      calcSSB(stats[[as.character(lastYr)]]$stock$had$stk)

  # Calculate TAC for this year
  tac <- calcTAC(ssb[[as.character(lastYr)]])
  print(paste("TAC in", curYr, "is", tac))

  # Apply TAC to fleet data (spread out between 4 steps in a year)
  tacPortion <- c(0.232, 0.351, 0.298, 0.119)
  targetFleet <- "future"
  updateAmount(targetFleet, curYr, 1, 1, tacPortion[[1]] * tac)
  updateAmount(targetFleet, curYr, 2, 1, tacPortion[[2]] * tac)
  updateAmount(targetFleet, curYr, 3, 1, tacPortion[[3]] * tac)
  updateAmount(targetFleet, curYr, 4, 1, tacPortion[[4]] * tac)

  # Forward the time
  stats[[as.character(curYr)]] <- gadgetr::runYear()

  # Get the latest runtime information
  status <- gadgetr::getEcosystemInfo()
}

## -----------------------------------------------------------------------------
# Calculate real recruitment
rec <- lapply(stats, function(x) calcRecruitment(x$stock$had$stk))

# Calculate real catch (future fleet)
catch <- lapply(stats, function(x) 
    sum(x$fleet$future$catch$had[, "biomassConsumed"]))


## ----plot, fig.height=5, fig.width=7, fig.fullwidth=TRUE, fig.cap = "Haddock simulation numbers"----
# Plot the world
maxy <- max(c(unlist(ssb), unlist(rec)))
cl <- rainbow(3)
plot(0, 0, xlim = c(1978, 2020), ylim = c(0, maxy), type = "n", xlab = "Year",
    ylab = "", main = "Haddock gadget model")
lines(names(ssb), ssb, col = cl[1], type = "l")
lines(names(rec), rec, col = cl[2], type = "l")
lines(names(catch), catch, col = cl[3], type = "l")
abline(v = 2000, col="darkorange", lwd=3, lty=2)
legend(1980, maxy, legend=c("SSB (had)", "Recruitment (had)", 
    "Catch (future fleet)"), col=cl, lty=1, cex=1, bg='lightblue1')

## -----------------------------------------------------------------------------
endGadget()

