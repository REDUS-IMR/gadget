library(testthat)
library(gadgetr)

test_check("gadgetr")
