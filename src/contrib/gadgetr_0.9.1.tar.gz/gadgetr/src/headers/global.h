#include "runid.h"
#include "errorhandler.h"
#ifndef GLOBAL_H
#define GLOBAL_H
 
extern RunID RUNID;
extern ErrorHandler handle;

#endif
