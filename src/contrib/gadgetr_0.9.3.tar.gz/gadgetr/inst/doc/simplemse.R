## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

# source: https://stackoverflow.com/questions/23114654
hook_output <- knitr::knit_hooks$get("output")
knitr::knit_hooks$set(output = function(x, options) {
   lines <- options$output.lines
   if (is.null(lines)) {
     return(hook_output(x, options))  # pass to default hook
   }
   x <- unlist(strsplit(x, "\n"))
   more <- "..."
   if (length(lines)==1) {        # first n lines
     if (length(x) > lines) {
       # truncate the output, but add ....
       x <- c(head(x, lines), more)
     }
   } else {
     x <- c(more, x[lines], more)
   }
   # paste these lines together
   x <- paste(c(x, ""), collapse = "\n")
   hook_output(x, options)
})

## ----eval=FALSE---------------------------------------------------------------
#  devtools::install_github("REDUS-IMR/gadget", ref="gadgetr")

## ---- a, eval=FALSE-----------------------------------------------------------
#  runPMSE <- function(seed = 1234) {

## ---- b, eval=FALSE-----------------------------------------------------------
#  library(gadgetr)

## ---- c, eval=FALSE-----------------------------------------------------------
#  # Get the path of the example haddock model
#  exPath <- gadgetr::loadExample()
#  print(exPath)
#  
#  # Initiate the haddock model
#  gadgetr::initGadget(exPath, "refinputfile")
#  
#  # Print the basic model information
#  gadgetr::getEcosystemInfo()
#  
#  # Init seed
#  set.seed(seed)

## ---- d, eval=FALSE-----------------------------------------------------------
#  # Calculate SSB
#  calcSSB <- function(stk) {
#      # Get SSB
#      subs <- stk[stk[, "age"] >= 3 & stk[, "step"] == 4, ]
#      ssb <- sum(subs[, "number"] * subs[, "meanWeights"])
#      return(ssb)
#  }

## ---- e, eval=FALSE-----------------------------------------------------------
#  # Calculate Recruitment
#  calcRecruitment <- function(stk) {
#      # Get Recruitment (based on fbar and only from the last step)
#      subs <- stk[stk[, "age"] == 1 & stk[, "step"] == 2, ]
#      return(sum(subs[, "number"]))
#  }

## ---- f, eval=FALSE-----------------------------------------------------------
#  # In this example, we assume that the haddock recruitment for a given year is
#  # equal to the historical geometric mean recruitment
#  fcRecruitment <- function(rec) {
#      rec <- unlist(rec)
#      return(exp(mean(log(rec))))
#  }

## ---- g, eval=FALSE-----------------------------------------------------------
#  # and calculating TAC is a matter of taking 40% of the stock's last year
#  # stock biomass value with added noise
#  calcTAC <- function(stk) {
#      # Get TSB
#      subs <- stk[stk[, "step"] == 4, ]
#      tsb <- sum(subs[, "number"] * subs[, "meanWeights"])
#      # Calculate error
#      err <- rnorm(1, 0, tsb * .25)
#      # Calculate TAC
#      tac <- .4 * (tsb + err)
#      return(tac)
#  }

## ---- h, eval=FALSE-----------------------------------------------------------
#  # Placeholders for values
#  stats <- list()
#  ssb <- list()
#  rec <- list()
#  
#  # Loop for the hindcast period
#  forecastYear <- 2000
#  status <- gadgetr::getEcosystemInfo()
#  while ( status[["time"]]["currentYear"] < forecastYear ) {
#    # Append stats
#    curYr <- as.character(status[["time"]]["currentYear"])
#    stats[[curYr]] <- gadgetr::runYear()
#    ssb[[curYr]] <- calcSSB(stats[[curYr]]$stock$had$stk)
#    rec[[curYr]] <- calcRecruitment(stats[[curYr]]$stock$had$stk)
#    # Get the latest runtime information
#    status <- gadgetr::getEcosystemInfo()
#  }

## ---- i, eval=FALSE-----------------------------------------------------------
#  # MSE loop
#  while ( status[["time"]]["finished"] != 1 ) {
#    # Time calculation
#    curYr <- status[["time"]]["currentYear"]
#    lastYr <- curYr - 1
#  
#    # Calculate Recruitment for this year
#    recNumber <- fcRecruitment(rec)
#    rec[[as.character(curYr)]] <- recNumber
#    print(paste("Recruitment in", curYr, "is", recNumber))
#  
#    # Apply recruitment number for this year haddock stock
#    # note that this is similar to the format found in "had.rec" file
#    updateRenewal("had", curYr, step = 1, area = 1, age = 1,
#        number = (recNumber/10000), mean = 16.41, sdev = 2.25 , alpha = 8.85e-6,
#        beta = 3.0257)
#  
#    # Calculate last year SSB
#    stk0 <- stats[[as.character(lastYr)]]$stock$had$stk
#    ssb[[as.character(lastYr)]] <- calcSSB(stk0)
#  
#    # Calculate TAC for this year
#    tac <- calcTAC(stk0)
#    print(paste("TAC in", curYr, "is", tac))
#  
#    # Apply TAC to fleet data (spread out over 4 quarter/step in a year)
#    # in percentage (i.e., sum(tacPortion) == 1)
#    tacPortion <- c(0.232, 0.351, 0.298, 0.119)
#    targetFleet <- "future"
#    updateAmount(targetFleet, curYr, 1, 1, tacPortion[[1]] * tac)
#    updateAmount(targetFleet, curYr, 2, 1, tacPortion[[2]] * tac)
#    updateAmount(targetFleet, curYr, 3, 1, tacPortion[[3]] * tac)
#    updateAmount(targetFleet, curYr, 4, 1, tacPortion[[4]] * tac)
#  
#    # Forward the time
#    stats[[as.character(curYr)]] <- gadgetr::runYear()
#  
#    # Get the latest runtime information
#    status <- gadgetr::getEcosystemInfo()
#  }

## ---- j, eval=FALSE-----------------------------------------------------------
#  print(rec)
#  # Calculate real catch (all fleets)
#  catch <- lapply(stats, function(x) {
#      sum(x$fleet$future$catch$had[, "biomassConsumed"], na.rm = TRUE) +
#      sum(x$fleet$comm$catch$had[, "biomassConsumed"], na.rm = TRUE) +
#      sum(x$fleet$survey$catch$had[, "biomassConsumed"], na.rm = TRUE)
#    })

## ---- k, eval=FALSE-----------------------------------------------------------
#  endGadget()

## ---- l, eval=FALSE-----------------------------------------------------------
#      return(list(ssb, rec, catch))
#  }

## -----------------------------------------------------------------------------
plotIt <- function(x) {
    singlePlot <- function(cat, name, title) {
        # Collect metrics
        z <- do.call(cbind, lapply(x, function(y) unlist(y[[cat]])))
        tab <- as.data.frame(z)
        tab$year <- as.numeric(rownames(tab))
        tab <- reshape(tab, varying=list(1:(ncol(tab)-1)), direction="long", v.names = name)
        fig <- ggplot(tab, aes_string("year", name)) +
                    stat_summary(geom = "line", fun = mean) +
                    stat_summary(geom = "ribbon", fun.data = mean_sdl, fun.args = list(mult = 1), fill = "red", alpha = 0.2) +
                    stat_summary(geom = "ribbon", fun.data = mean_cl_normal, fill = "red", alpha = 0.3) + 
                    labs(title=paste("Haddock", title), y="")
        return(fig)
    }

  ssbplot <- singlePlot(1, "ssb", "SSB")
  recplot <- singlePlot(2, "rec", "Recruitment")
  catchplot <- singlePlot(3, "catch", "Catch")

  return(list(ssbplot, recplot, catchplot))
}

## ----ref.label=c('a','b','c','d','e','f','g','h','i','j','k','l'), echo=FALSE----
runPMSE <- function(seed = 1234) {
library(gadgetr)
# Get the path of the example haddock model
exPath <- gadgetr::loadExample()
print(exPath)

# Initiate the haddock model
gadgetr::initGadget(exPath, "refinputfile")

# Print the basic model information
gadgetr::getEcosystemInfo()

# Init seed
set.seed(seed)
# Calculate SSB
calcSSB <- function(stk) {
    # Get SSB
    subs <- stk[stk[, "age"] >= 3 & stk[, "step"] == 4, ]
    ssb <- sum(subs[, "number"] * subs[, "meanWeights"])
    return(ssb)
}
# Calculate Recruitment
calcRecruitment <- function(stk) {
    # Get Recruitment (based on fbar and only from the last step)
    subs <- stk[stk[, "age"] == 1 & stk[, "step"] == 2, ]
    return(sum(subs[, "number"]))
}
# In this example, we assume that the haddock recruitment for a given year is
# equal to the historical geometric mean recruitment
fcRecruitment <- function(rec) {
    rec <- unlist(rec)
    return(exp(mean(log(rec))))
}
# and calculating TAC is a matter of taking 40% of the stock's last year
# stock biomass value with added noise
calcTAC <- function(stk) {
    # Get TSB
    subs <- stk[stk[, "step"] == 4, ]
    tsb <- sum(subs[, "number"] * subs[, "meanWeights"])
    # Calculate error
    err <- rnorm(1, 0, tsb * .25)
    # Calculate TAC
    tac <- .4 * (tsb + err)
    return(tac)
}
# Placeholders for values
stats <- list()
ssb <- list()
rec <- list()

# Loop for the hindcast period
forecastYear <- 2000
status <- gadgetr::getEcosystemInfo()
while ( status[["time"]]["currentYear"] < forecastYear ) {
  # Append stats
  curYr <- as.character(status[["time"]]["currentYear"])
  stats[[curYr]] <- gadgetr::runYear()
  ssb[[curYr]] <- calcSSB(stats[[curYr]]$stock$had$stk)
  rec[[curYr]] <- calcRecruitment(stats[[curYr]]$stock$had$stk)
  # Get the latest runtime information
  status <- gadgetr::getEcosystemInfo()
}
# MSE loop
while ( status[["time"]]["finished"] != 1 ) {
  # Time calculation
  curYr <- status[["time"]]["currentYear"]
  lastYr <- curYr - 1
  
  # Calculate Recruitment for this year
  recNumber <- fcRecruitment(rec)
  rec[[as.character(curYr)]] <- recNumber
  print(paste("Recruitment in", curYr, "is", recNumber))

  # Apply recruitment number for this year haddock stock
  # note that this is similar to the format found in "had.rec" file
  updateRenewal("had", curYr, step = 1, area = 1, age = 1,
      number = (recNumber/10000), mean = 16.41, sdev = 2.25 , alpha = 8.85e-6,
      beta = 3.0257)

  # Calculate last year SSB
  stk0 <- stats[[as.character(lastYr)]]$stock$had$stk
  ssb[[as.character(lastYr)]] <- calcSSB(stk0)

  # Calculate TAC for this year
  tac <- calcTAC(stk0)
  print(paste("TAC in", curYr, "is", tac))

  # Apply TAC to fleet data (spread out over 4 quarter/step in a year)
  # in percentage (i.e., sum(tacPortion) == 1)
  tacPortion <- c(0.232, 0.351, 0.298, 0.119)
  targetFleet <- "future"
  updateAmount(targetFleet, curYr, 1, 1, tacPortion[[1]] * tac)
  updateAmount(targetFleet, curYr, 2, 1, tacPortion[[2]] * tac)
  updateAmount(targetFleet, curYr, 3, 1, tacPortion[[3]] * tac)
  updateAmount(targetFleet, curYr, 4, 1, tacPortion[[4]] * tac)

  # Forward the time
  stats[[as.character(curYr)]] <- gadgetr::runYear()

  # Get the latest runtime information
  status <- gadgetr::getEcosystemInfo()
}
print(rec)
# Calculate real catch (all fleets)
catch <- lapply(stats, function(x) {
    sum(x$fleet$future$catch$had[, "biomassConsumed"], na.rm = TRUE) +
    sum(x$fleet$comm$catch$had[, "biomassConsumed"], na.rm = TRUE) +
    sum(x$fleet$survey$catch$had[, "biomassConsumed"], na.rm = TRUE)
  })
endGadget()
    return(list(ssb, rec, catch))
}

## ----output.lines=25----------------------------------------------------------
library(ggplot2)
result <- runPMSE()

## ----plot1, fig.height=5, fig.width=7, fig.fullwidth=TRUE, fig.cap="Haddock model (single-run) performance metrics"----
plots <- plotIt(list(result))
print(plots[[1]])
print(plots[[2]])
print(plots[[3]])

## -----------------------------------------------------------------------------
library(parallel)

chk <- Sys.getenv("_R_CHECK_LIMIT_CORES_", "")

if (nzchar(chk) && chk == "TRUE") {
    # use 2 cores in CRAN/actions
    num_workers <- 2L
} else {
    # use all cores in devtools::test()
    num_workers <- detectCores()
}

cl <- makeCluster(num_workers, type = "PSOCK")

# Run
seeds <- round(runif(100, 1, 10000))
result <- parLapply(cl, seeds, runPMSE)

stopCluster(cl)

plots <- plotIt(result)


## ----plot2, fig.height=5, fig.width=7, fig.fullwidth=TRUE, fig.cap="Haddock model (parallel-runs) performance metrics"----
print(plots[[1]])
print(plots[[2]])
print(plots[[3]])

