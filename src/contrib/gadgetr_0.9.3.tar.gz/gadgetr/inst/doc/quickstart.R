## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
#  devtools::install_github("REDUS-IMR/gadget", ref="gadgetr")

## ----setup--------------------------------------------------------------------
library(gadgetr)

## -----------------------------------------------------------------------------
# Get the path of the example haddock data
exPath <- gadgetr::loadExample()
print(exPath)

## -----------------------------------------------------------------------------
# Initiate the haddock model
gadgetr::initGadget(exPath, "refinputfile")

## -----------------------------------------------------------------------------
# Get the initial information
initial <- gadgetr::getEcosystemInfo()
print(initial)

# Print start year
print(initial$time["currentYear"])
# Print initial step number
print(initial$time["currentTime"])
# Print final step number
print(initial$time["totalSteps"])

## -----------------------------------------------------------------------------
# Variable for counting step
lengthStep <- 1

# Loop for all steps
stats <- list()
while (TRUE){
  # Append stats
  stats[[lengthStep]] <- gadgetr::runStep()
  # Stop at the end of time
  status <- gadgetr::getEcosystemInfo()
  if(status[["time"]]["finished"] == 1) break
  lengthStep <- lengthStep + 1
}

print(lengthStep)

# Get termination information
term <- gadgetr::getEcosystemInfo()

# Print end year
print(term$time["currentYear"])
print(initial$time["currentYear"] + (lengthStep / 4) - 1)

# Print last step number
print(term$time["currentTime"])
print(lengthStep)

## -----------------------------------------------------------------------------
# Print out all status
print(names(stats[[1]]))
print(names(stats[[1]]$stock))
print(names(stats[[1]]$fleet))

# Print haddock stock in step 1
print(names(stats[[1]]$stock$had))
print(tail(stats[[1]]$stock$had$stk))

# Print haddock recruitment in step 1
print(names(stats[[1]]$stock$had$rec))
print(tail(stats[[1]]$stock$had$rec$renew))
print(stats[[1]]$stock$had$rec$spawn)

# Print haddock catch by commercial fleet in step 1
print(names(stats[[1]]$fleet))
print(names(stats[[1]]$fleet$comm$catch))
print(tail(stats[[1]]$fleet$comm$catch$had))

## -----------------------------------------------------------------------------
# Sim cleanup
gadgetr::endGadget()

