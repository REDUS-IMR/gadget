#' gadgetr
#' 
#' Gadget program (https://github.com/Hafro/gadget) re-packaged as an R package
#' 
#' @docType package
#' @author Ibrahim Umar
#' @import Rcpp
#' @importFrom Rcpp evalCpp
#' @useDynLib gadgetr
#' @name gadgetr
#' @keywords internal
NULL
