#ifndef aarand_h
#define aarand_h

namespace myrand {
	void srand(unsigned int);
	int rand(void);
}

#endif
